import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';
import { log } from 'util';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.scss']
})
export class GenerateReportComponent implements OnInit {
  libItems : any = [];
  search : string = '';
  constructor(private libraryService  :LibraryService) { }

  ngOnInit() {
    this.libraryService.generateAReport().subscribe(report=>{
      this.libItems = report;
      console.log(report);
    });
  }

  fitlerData(){
    console.log(this.search);  
    this.libraryService.generateAReport().subscribe(report=>{
      this.libItems = report.filter(obj => obj.w1698446_readerName == this.search );
      console.log(this.libItems);
      
    })
  }

}
