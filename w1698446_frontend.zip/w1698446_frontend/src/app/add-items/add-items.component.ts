import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.scss']
})
export class AddItemsComponent implements OnInit {

  radioButton: string = 'book';
  enterAuthor = ''; authorsArray = [];
  enterLanguage = ''; languagesArray = [];
  enterSubtitle = ''; subtitlesArray = [];
  enterActor = ''; actorArray = [];
  selectedDate: any;
  slots: any = {};


  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
    this.selectedDate = new Date();
    this.loadData();
  }

  AddAuthorsArray() {
    this.authorsArray.push(this.enterAuthor)
    this.enterAuthor = '';
  }

  AddLanguagesArray() {
    this.languagesArray.push(this.enterLanguage)
    this.enterLanguage = '';
  }
  AddSubtitlesArray() {
    this.subtitlesArray.push(this.enterSubtitle)
    this.enterSubtitle = '';
  }
  AddActorArray() {
    this.actorArray.push(this.enterActor)
    this.enterActor = '';
  }
  saveAnItem(value) {

    value.publicationDate = null;

    if (this.radioButton == 'book') {

      var books = {

        "w1698446_ItemISBN": value.w1698446_ItemISBN,
        "w1698446_itemTitle": value.w1698446_itemTitle,
        "w1698446_itemSector": value.w1698446_itemSector,
        "w1698446_authorOfBook": value.w1698446_authorOfBook,
        "w1698446_publisherOfBook": value.w1698446_publisherOfBook,
        "w1698446_totPages": value.w1698446_totPages,

      };

      var book = {
        'book': books,
        'dvd': null
      };

      this.libraryService.saveAllItems(book).subscribe(rslt => {

        if (rslt) {

          alert('Book is successfully saved in the library system');

        } else {

          alert('Error occured while saving a book to the library system');
        }
      });

    } else {

      var dvds = {

        "w1698446_ItemISBN": value.w1698446_ItemISBN,
        "w1698446_itemTitle": value.w1698446_itemTitle,
        "w1698446_itemSector": value.w1698446_itemSector,
        "w1698446_availableLanguages": value.w1698446_availableLanguages,
        "w1698446_availableSubtitles": value.w1698446_availableSubtitles,
        "w1698446_producer": value.w1698446_producer,
        "w1698446_actors": value.w1698446_actors
      };

      var dvd = {
        'book': null,
        'dvd': dvds
      };

      this.libraryService.saveAllItems(dvd).subscribe(rslt => {

        if (rslt) {

          alert('DVD is successfully saved in the library system');

        } else {

          alert('Error occured while saving a DVD to the library system');
        }
      });
    }
  }

  onClick() {
    console.log(this.selectedDate)
  }

  loadData() {
    this.libraryService.getAvailableSlots().subscribe(rslt => {
      this.slots=rslt;
      console.log(this.slots);
    });
  }
}
