import { FilterTitlePipe } from './filter-title.pipe';

describe('FilterTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
