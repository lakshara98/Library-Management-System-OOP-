import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddItemsComponent } from './add-items/add-items.component';
import { BorrowItemsComponent } from './borrow-items/borrow-items.component';
import { DeleteItemsComponent } from './delete-items/delete-items.component';
import { DisplayItemsComponent } from './display-items/display-items.component';
import { ReturnItemsComponent } from './return-items/return-items.component';
import { GenerateReportComponent } from './generate-report/generate-report.component';
import { MenuComponent } from './menu/menu.component';

const routes: Routes = [
  {path:'',component:MenuComponent},
  {path: 'add', component: AddItemsComponent},
  {path: 'borrow', component: BorrowItemsComponent},
  {path: 'delete', component: DeleteItemsComponent},
  {path: 'display', component: DisplayItemsComponent},
  {path: 'return', component: ReturnItemsComponent},
  {path: 'generate', component: GenerateReportComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
