import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';

@Component({
  selector: 'app-delete-items',
  templateUrl: './delete-items.component.html',
  styleUrls: ['./delete-items.component.scss']
})
export class DeleteItemsComponent implements OnInit {

  deletedItemDetails:any ={};
  
  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
  }

  deleteAnItem(isbn) {

    this.libraryService.deletedItems(isbn).subscribe(rslt => {
      this.deletedItemDetails = rslt;
      alert(this.deletedItemDetails.type + ' is successfully deleted.  ' + this.deletedItemDetails.spaceCount + ' more spaces are available in the system')
      
    });
  }

  
}
