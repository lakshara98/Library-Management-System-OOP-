import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddItemsComponent } from './add-items/add-items.component';
import { DeleteItemsComponent } from './delete-items/delete-items.component';
import { BorrowItemsComponent } from './borrow-items/borrow-items.component';
import { ReturnItemsComponent } from './return-items/return-items.component';
import { DisplayItemsComponent } from './display-items/display-items.component';
import { GenerateReportComponent } from './generate-report/generate-report.component';
import { MenuComponent } from './menu/menu.component';
import { FormsModule} from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from 'selenium-webdriver/http';

import { DlDateTimePickerDateModule } from 'angular-bootstrap-datetimepicker';
import { FilterTitlePipe } from './filter-title.pipe';

declare var require: any;


@NgModule({
  declarations: [
    AppComponent,
    AddItemsComponent,
    DeleteItemsComponent,
    BorrowItemsComponent,
    ReturnItemsComponent,
    DisplayItemsComponent,
    GenerateReportComponent,
    MenuComponent,
    FilterTitlePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DlDateTimePickerDateModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
