import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';

@Component({
  selector: 'app-display-items',
  templateUrl: './display-items.component.html',
  styleUrls: ['./display-items.component.scss'],

})

export class DisplayItemsComponent implements OnInit {

  items: any = [];
  search: any = '';
  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.libraryService.displayAllItems().subscribe(items=>{
      console.log(items);
      if(this.search == ''){
        this.items = items;
      }else if (this.search != ''){
        this.items  = items.filter(filter=> filter.title == this.search);
      }
    });
  }

}
