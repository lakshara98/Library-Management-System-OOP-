import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';
import { log } from 'util';

@Component({
  selector: 'app-return-items',
  templateUrl: './return-items.component.html',
  styleUrls: ['./return-items.component.scss']
})
export class ReturnItemsComponent implements OnInit {

  items: any = [];
  radioButton: string = 'returnBook';
  search : any = '';

  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
    // this.libraryService.displayAllItems().subscribe(items => {
    //   console.log(items);
    //   this.items = items;

    // });
    this.loadData();
  }


  returnAnItem(ISBN) {
    console.log(ISBN)
    this.libraryService.returnAllItems(ISBN).subscribe(rslt => {
      console.log(rslt);
      var check = rslt.toString();
      if (check == "null") {

        alert('No amount is been charged. You have returned the item successfully')

      } else {

        alert('You have returned the item successfully. Due amount is ' + rslt)
      }
    });
  }

  loadData(){
    this.libraryService.displayAllItems().subscribe(rslt=>{
      this.items = rslt;
    })
  }

}
