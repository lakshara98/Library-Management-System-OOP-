import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../services/library.service';

@Component({
  selector: 'app-borrow-items',
  templateUrl: './borrow-items.component.html',
  styleUrls: ['./borrow-items.component.scss']
})
export class BorrowItemsComponent implements OnInit {

  items: any = [];
  radioradioButton: any = 'book';
  item: any = [];
  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
    this.libraryService.displayAllItems().subscribe(items => {
      console.log(items);
      this.items = items;

    });
  }

  borrowAnItem(borrowItem) {

    let dateFormat = require('dateformat');

    let presentDateTime = new Date();
    let getsReturnedDate = new Date();

    var borrowDateAsString = dateFormat(presentDateTime, "dd,mm,yyyy,h,MM,ss,TT").toString();
    var borrowSplittedString = borrowDateAsString.split(",", 7);

    if (borrowItem.itemPreference === 'book') {
      getsReturnedDate.setDate(getsReturnedDate.getDate() + 7);
    } else {
      getsReturnedDate.setDate(getsReturnedDate.getDate() + 3);
    }

    var formatOfReturnedTime = dateFormat(getsReturnedDate, "dd,mm,yyyy,h,MM,ss,TT").toString();
    var returnSplittedString = formatOfReturnedTime.split(",", 7);

    var returnDateOfItem = {
      "years": borrowSplittedString[2],
      "months": borrowSplittedString[1],
      "days": borrowSplittedString[0],
      "hours": borrowSplittedString[3],
      "minutes": borrowSplittedString[4]
    };

    var borrowDateOfItem = {
      "years": returnSplittedString[2],
      "months": returnSplittedString[1],
      "days": returnSplittedString[0],
      "hours": returnSplittedString[3],
      "minutes": returnSplittedString[4]
    }

    if (borrowItem.itemPreference === 'book') {

      var bBook = {
        "isbn": borrowItem.addISBN,
        "borrowdate": returnDateOfItem,
        "returndate": borrowDateOfItem,
        "uid": borrowItem.borrowID,
        "name": borrowItem.borrowName,
        "phoneNumber": borrowItem.borrowMobile,
        "email": borrowItem.borrowEmail,
        "type": true
      };

      this.libraryService.borrowedItems(bBook).subscribe(rslt => {

        console.log(rslt);

        if (rslt == "null") {

          alert("You have sucessfully borrowed a book");

        } else {

          alert("Item is not available...  Available Date : "+rslt);
        }
      });


    } else {

      var bDVD = {

        "isbn": borrowItem.addISBN,
        "borrowdate": borrowDateOfItem,
        "returndate": returnDateOfItem,
        "uid": borrowItem.borrowID,
        "name": borrowItem.borrowName,
        "phoneNumber": borrowItem.borrowMobile,
        "email": borrowItem.borrowEmail,
        "type": false
      };

      this.libraryService.borrowedItems(bDVD).subscribe(rslt => {

        console.log(rslt);

        if (rslt == "null") {

          alert("You have sucessfully borrowed a DVD");

        } else {

          alert("Item is not available...  Available Date : "+rslt);
        }
      });
    }
  }
}

