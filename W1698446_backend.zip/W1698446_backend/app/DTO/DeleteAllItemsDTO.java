package DTO;

import models.LibraryItem;

public class DeleteAllItemsDTO {

    private int spaceCount;

    private String type;

    public DeleteAllItemsDTO(int spaceCount, String type) {
        this.spaceCount = spaceCount;
        this.type = type;
    }

    public int getSpaceCount() {
        return spaceCount;
    }

    public void setSpaceCount(int spaceCount) {
        this.spaceCount = spaceCount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
