package DTO;

public class DisplayAllItemsDTO {

    private String ISBN;

    private String title;

    private String type;

    private boolean isAvailable;

    public DisplayAllItemsDTO(String ISBN, String title, String type, boolean isAvailable) {
        this.ISBN = ISBN;
        this.title = title;
        this.type = type;
        this.isAvailable = isAvailable;
    }


    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
