package services;

import DTO.*;
import com.avaje.ebean.Ebean;
import com.avaje.ebean.Model;
import models.Book;
import models.BorrowItems;
import models.DVD;
import org.joda.time.Period;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WestminsterLibraryManager implements LibraryManager {

    private static final Model.Finder<Long, Book> findABook = new Model.Finder<>(Book.class);
    private static final Model.Finder<Long, DVD> findADVD = new Model.Finder<>(DVD.class);
    private static final Model.Finder<Long, BorrowItems> findBorrowItems = new Model.Finder<>(BorrowItems.class);


    //method to add new items to the library system
    @Override
    public CountOfItemsDTO addNewItem() {

        CountOfItemsDTO countOfItemsDTO;

        int countOfBooks = findABook.findRowCount();
        int countOfDVDs = findADVD.findRowCount();

        //calculating total number of items available
        int totNoOfItems = countOfBooks + countOfDVDs;

        //Calculating number of remaining books and DVDs separately
        if(totNoOfItems > 0){

            int NoOfBooksRemaining = 100 - countOfBooks;
            int NoOfDVDsRemaining = 50 - countOfDVDs;

            countOfItemsDTO = new CountOfItemsDTO(NoOfBooksRemaining , NoOfDVDsRemaining);

        }else{

            countOfItemsDTO = new CountOfItemsDTO(100,50);
        }

        return countOfItemsDTO;

    }


    //Method to save all the added items
    @Override
    public boolean saveAllAddedItems(AddAllItemsDTO addAllItemsDTO) {

        //Declaring a variable to check if saving items is successful
        boolean isSuccessfull;

        //If the values for the fields in book is been added
        if(addAllItemsDTO.getBook() != null){

            Ebean.save(addAllItemsDTO.getBook());
            isSuccessfull = true;

            //If the values for the fields in DVD is been added
        }else if(addAllItemsDTO.getDvd() != null){

            Ebean.save(addAllItemsDTO.getDvd());
            isSuccessfull = true;

        }else{

            isSuccessfull = false;
        }

        return isSuccessfull;
    }


    //Method to delete a specific item from the library system
    @Override
    public DeleteAllItemsDTO DeleteAnItem(String ISBN) {

        DeleteAllItemsDTO deleteAllItemsDTO;

        String typeOfdeletedItem = "";

        Book deleteABook = findABook.where().eq("w1698446_ItemISBN",ISBN).findUnique();
        DVD deleteADVD = findADVD.where().eq("w1698446_ItemISBN",ISBN).findUnique();

        //If the item you want to delete is a book and it is available to be deleted
        if(deleteABook != null){

            Ebean.delete(deleteABook);
            typeOfdeletedItem = "Book";

            //If the item you want to delete is a DVD and it is available to be deleted
        }else if(deleteADVD != null){

            Ebean.delete(deleteADVD);
            typeOfdeletedItem = "DVD";

        }

        int countOfAllLibraryBooks = findABook.findRowCount();
        int countOfAllLibraryDVDs = findADVD.findRowCount();

        //Number of spaces left in the library
        int SpacesLeftInLibrary = 150 - (countOfAllLibraryBooks + countOfAllLibraryDVDs);

        deleteAllItemsDTO = new DeleteAllItemsDTO(SpacesLeftInLibrary,typeOfdeletedItem);

        return deleteAllItemsDTO;
    }

    //Method to display all the items available in the library system
    @Override
    public ArrayList<DisplayAllItemsDTO> displayLibraryItems() {

        ArrayList<DisplayAllItemsDTO> displayAllItemsDTOS = new ArrayList<>();

        //List of all the books in the library
        List<Book> allBooksInLibrary = findABook.findList();
        //List of all the DVDs in the library
        List<DVD> allDVDsInLibrary = findADVD.findList();
        //List of all the borrowed items from the library
        List<BorrowItems> availableItems = findBorrowItems.where().eq("w1698446_is_item_return", false).findList();

        for (Book book : allBooksInLibrary){

            boolean isAvailble_book;

            BorrowItems bk = availableItems.stream().filter(x -> book.getW1698446_ItemISBN().equals(x.getW1698446_itemISBN())).findAny().orElse(null);

            if(bk != null){
                isAvailble_book = false;
            }else{
                isAvailble_book = true;
            }

            String itemTitle = book.getW1698446_itemTitle();
            String itemType = "Book";
            String itemISBN = book.getW1698446_ItemISBN();

            displayAllItemsDTOS.add(new DisplayAllItemsDTO(itemISBN,itemTitle,itemType,isAvailble_book));
        }

        for(DVD dvd : allDVDsInLibrary){

            boolean isAvailable_dvd;

            BorrowItems d = availableItems.stream().filter(x -> dvd.getW1698446_ItemISBN().equals(x.getW1698446_itemISBN())).findAny().orElse(null);

            if(d != null){
                isAvailable_dvd = false;
            }else{
                isAvailable_dvd = true;
            }

            String itemTitle = dvd.getW1698446_itemTitle();
            String itemType = "DVD";
            String itemISBN = dvd.getW1698446_ItemISBN();

            displayAllItemsDTOS.add(new DisplayAllItemsDTO(itemISBN,itemTitle,itemType,isAvailable_dvd));
        }


        return displayAllItemsDTOS;

    }

    //method to borrow items from the library
    @Override
    public String BorrowItem(BorrowAllItemsDTO borrowAllItemsDTO) {

        String returnedDateOfItem;

        String borrowedDateOfItems = borrowAllItemsDTO.getBorrowdate().getYears() + "/" + borrowAllItemsDTO.getBorrowdate().getMonths() + "/" + borrowAllItemsDTO.getBorrowdate().getDays() + " " + borrowAllItemsDTO.getBorrowdate().getHours() + ":" + borrowAllItemsDTO.getBorrowdate().getMinutes();
        String returnedDateOfItems = borrowAllItemsDTO.getReturndate().getYears() + "/" + borrowAllItemsDTO.getReturndate().getMonths() + "/" + borrowAllItemsDTO.getReturndate().getDays() + " " + borrowAllItemsDTO.getReturndate().getHours() + ":" + borrowAllItemsDTO.getReturndate().getMinutes();


        BorrowItems borrowItems = new BorrowItems(borrowAllItemsDTO.getUid(), borrowAllItemsDTO.getName(), borrowAllItemsDTO.getPhoneNumber(), borrowAllItemsDTO.getEmail(),
                borrowedDateOfItems, returnedDateOfItems, borrowAllItemsDTO.getIsbn(), borrowAllItemsDTO.isType(),false,"");

        //Check for the item to be borrowed
        BorrowItems borrowedItemsChecker = findBorrowItems.where().eq("w1698446_item_isbn", borrowAllItemsDTO.getIsbn()).eq("w1698446_is_item_return",false).findUnique();

        //If the item is available in borrowed items
        if(borrowedItemsChecker != null){

            returnedDateOfItem = borrowedItemsChecker.getW1698446_returnedDate();

        }else {

            returnedDateOfItem = "null";
            Ebean.save(borrowItems);
        }

        return returnedDateOfItem;
    }

    //A method to return items thathas been borrowed
    @Override
    public String ReturnItem(String ISBN) {

        //Variable to save the fee(if there is any)
        String countValue;

        BorrowItems returnAllBorrowedItems = findBorrowItems.where().eq("w1698446_item_isbn",ISBN).eq("w1698446_is_item_return",false).findUnique();


        Date dateTime = new Date();
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");

        try {
            Date returnedDateOfItems = dateTimeFormat.parse(returnAllBorrowedItems.getW1698446_returnedDate());

            if(!dateTime.before(returnedDateOfItems)){

                Period period = new Period(dateTime.getTime(), returnedDateOfItems.getTime());
                int additionalHours = period.getHours();

                    int gapOfDays = returnedDateOfItems.getDay() - dateTime.getDay();

                    //If the book is not returned within a week
                    //Fee of 0.5 will be added foe every hour after exceeding one week and 3 days
                    if(gapOfDays > 3){

                        double temppCountValue = 0.5 * additionalHours;
                        countValue = String.valueOf(temppCountValue);

                    //fee of 0.2 will be added for every hour after exceeding one week
                    }else{

                        double temppCountValue = 0.2 * additionalHours;
                        countValue = String.valueOf(temppCountValue);
                    }


            }else {
                //A fine won't be added If the book is returned within a week
                countValue = "null";
            }

            returnAllBorrowedItems.setW1698446_isItemReturn(true);
            returnAllBorrowedItems.setW1698446_countValue(countValue);

            Ebean.update(returnAllBorrowedItems);

        } catch (ParseException ex) {

            countValue = "null";
            ex.printStackTrace();
        }


        return countValue;
    }

    //A method to Generate a report
    @Override
    public ArrayList<BorrowItems> createAReport() {

        List<BorrowItems> tempDataToTheReport = findBorrowItems.orderBy("coalesce(w1698446_borrowed_date, w1698446_returned_date) DESC").findList();

        ArrayList<BorrowItems> dataToTheReport = new ArrayList<>(tempDataToTheReport);

        return dataToTheReport;
    }
}
