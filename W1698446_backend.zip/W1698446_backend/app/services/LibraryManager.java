package services;

import DTO.*;
import models.BorrowItems;

import java.util.ArrayList;

public interface LibraryManager {

     CountOfItemsDTO addNewItem();

     boolean saveAllAddedItems(AddAllItemsDTO addAllItemsDTO);

     DeleteAllItemsDTO DeleteAnItem(String ISBN);

     ArrayList<DisplayAllItemsDTO> displayLibraryItems();

     String BorrowItem(BorrowAllItemsDTO borrowAllItemsDTO);

     String ReturnItem(String ISBN);

     ArrayList<BorrowItems> createAReport();

}
