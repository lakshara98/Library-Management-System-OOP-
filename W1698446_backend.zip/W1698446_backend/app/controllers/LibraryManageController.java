package controllers;

import DTO.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import models.BorrowItems;
import play.Logger;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import services.LibraryManager;

import javax.inject.Inject;
import java.util.ArrayList;

public class LibraryManageController extends Controller {

    @Inject
    private LibraryManager libraryManager;

    @Inject
    private ObjectMapper objectMapper;


    public Result DeleteItem(String isbn){

        DeleteAllItemsDTO deleteAllItemsDTO = libraryManager.DeleteAnItem(isbn);

        return ok(Json.toJson(deleteAllItemsDTO));

    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result SaveItem(){

        JsonNode jsonNode = request().body().asJson();

        AddAllItemsDTO addAllItemsDTO = null;

        try {
            addAllItemsDTO = objectMapper.treeToValue(jsonNode, AddAllItemsDTO.class);


            boolean isSuccess = libraryManager.saveAllAddedItems(addAllItemsDTO);

            return ok(Json.toJson(isSuccess));

        }catch (JsonProcessingException e) {
            Logger.error(e.getMessage());
            return badRequest("Not Json" , e.getMessage());
        }

    }

    public Result DisplayItems(){

        ArrayList<DisplayAllItemsDTO> itemDTOList = libraryManager.displayLibraryItems();

        return ok(Json.toJson(itemDTOList));
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result BorrowItem(){

        JsonNode jsonNode = request().body().asJson();

        BorrowAllItemsDTO borrowHistory = null;

        try {
            borrowHistory = objectMapper.treeToValue(jsonNode, BorrowAllItemsDTO.class);


            String date = libraryManager.BorrowItem(borrowHistory);

            return ok(Json.toJson(date));

        }catch (JsonProcessingException e) {
            Logger.error(e.getMessage());
            return badRequest("Not Json" , e.getMessage());
        }
    }

    public Result AvailableSlots(){

        CountOfItemsDTO countOfItemsDTO = libraryManager.addNewItem();

        return ok(Json.toJson(countOfItemsDTO));
    }


    public Result ReturnItem(String isbn){

        String amount = libraryManager.ReturnItem(isbn);

        return ok(Json.toJson(amount));
    }


    public Result GenereateReport(){

        ArrayList<BorrowItems> borrowHistories = libraryManager.createAReport();

        return ok(Json.toJson(borrowHistories));
    }
}
