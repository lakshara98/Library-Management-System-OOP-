package models;

import com.avaje.ebean.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class Reader {

    private String w1698446_readerId;

    private String w1698446_readerName;

    private String w1698446_readerPhone;

    private String w1698446_readerEmail;

    public Reader(String w1698446_readerId, String w1698446_readerName, String w1698446_readerPhone, String w1698446_readerEmail) {
        this.w1698446_readerId = w1698446_readerId;
        this.w1698446_readerName = w1698446_readerName;
        this.w1698446_readerPhone = w1698446_readerPhone;
        this.w1698446_readerEmail = w1698446_readerEmail;
    }

    public String getW1698446_readerId() {
        return w1698446_readerId;
    }

    public void setW1698446_readerId(String w1698446_readerId) {
        this.w1698446_readerId = w1698446_readerId;
    }

    public String getW1698446_readerName() {
        return w1698446_readerName;
    }

    public void setW1698446_readerName(String w1698446_readerName) {
        this.w1698446_readerName = w1698446_readerName;
    }

    public String getW1698446_readerPhone() {
        return w1698446_readerPhone;
    }

    public void setW1698446_readerPhone(String w1698446_readerPhone) {
        this.w1698446_readerPhone = w1698446_readerPhone;
    }

    public String getW1698446_readerEmail() {
        return w1698446_readerEmail;
    }

    public void setW1698446_readerEmail(String w1698446_readerEmail) {
        this.w1698446_readerEmail = w1698446_readerEmail;
    }
}
