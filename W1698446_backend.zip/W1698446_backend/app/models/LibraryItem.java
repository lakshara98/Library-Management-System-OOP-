package models;

import javax.persistence.*;


@MappedSuperclass
public abstract class LibraryItem {

    @Id
    private String w1698446_ItemISBN;

    private String w1698446_itemTitle;

    private String w1698446_itemSector;

    private String w1698446_dateOfPublication;

    public LibraryItem(String w1698446_ItemISBN, String w1698446_itemTitle, String w1698446_itemSector, String w1698446_dateOfPublication) {
        this.w1698446_ItemISBN = w1698446_ItemISBN;
        this.w1698446_itemTitle = w1698446_itemTitle;
        this.w1698446_itemSector = w1698446_itemSector;
        this.w1698446_dateOfPublication = w1698446_dateOfPublication;
    }

    public String getW1698446_ItemISBN() {
        return w1698446_ItemISBN;
    }

    public void setW1698446_ItemISBN(String w1698446_ItemISBN) {
        this.w1698446_ItemISBN = w1698446_ItemISBN;
    }

    public String getW1698446_itemTitle() {
        return w1698446_itemTitle;
    }

    public void setW1698446_itemTitle(String w1698446_itemTitle) {
        this.w1698446_itemTitle = w1698446_itemTitle;
    }

    public String getW1698446_itemSector() {
        return w1698446_itemSector;
    }

    public void setW1698446_itemSector(String w1698446_itemSector) {
        this.w1698446_itemSector = w1698446_itemSector;
    }

    public String getW1698446_dateOfPublication() {
        return w1698446_dateOfPublication;
    }

    public void setW1698446_dateOfPublication(String w1698446_dateOfPublication) {
        this.w1698446_dateOfPublication = w1698446_dateOfPublication;
    }
}
