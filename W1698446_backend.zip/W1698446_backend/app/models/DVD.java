package models;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "w1698446_DVD")
public class DVD extends LibraryItem {

    private String w1698446_availableLanguages;

    private String w1698446_availableSubtitles;

    private String w1698446_producer;

    private String w1698446_actors;

    public DVD(String w1698446_ItemISBN, String w1698446_itemTitle, String w1698446_itemSector, String w1698446_dateOfPublication, String w1698446_availableLanguages, String w1698446_availableSubtitles, String w1698446_producer, String w1698446_actors) {
        super(w1698446_ItemISBN, w1698446_itemTitle, w1698446_itemSector, w1698446_dateOfPublication);
        this.w1698446_availableLanguages = w1698446_availableLanguages;
        this.w1698446_availableSubtitles = w1698446_availableSubtitles;
        this.w1698446_producer = w1698446_producer;
        this.w1698446_actors = w1698446_actors;
    }

    public String getW1698446_actors() {
        return w1698446_actors;
    }

    public void setW1698446_actors(String w1698446_actors) {
        this.w1698446_actors = w1698446_actors;
    }

    public String getW1698446_availableLanguages() {
        return w1698446_availableLanguages;
    }

    public void setW1698446_availableLanguages(String w1698446_availableLanguages) {
        this.w1698446_availableLanguages = w1698446_availableLanguages;
    }

    public String getW1698446_availableSubtitles() {
        return w1698446_availableSubtitles;
    }

    public void setW1698446_availableSubtitles(String w1698446_availableSubtitles) {
        this.w1698446_availableSubtitles = w1698446_availableSubtitles;
    }

    public String getW1698446_producer() {
        return w1698446_producer;
    }

    public void setW1698446_producer(String w1698446_producer) {
        this.w1698446_producer = w1698446_producer;
    }
}
