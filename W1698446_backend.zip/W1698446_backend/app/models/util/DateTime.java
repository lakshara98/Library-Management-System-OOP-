package models.util;



public class DateTime {

    private int days;
    private int months;
    private int years;
    private int hours;
    private int minutes;

    public DateTime(int days, int months, int years, int hours, int minutes) {
        this.days = days;
        this.months = months;
        this.years = years;
        this.hours = hours;
        this.minutes = minutes;
    }

    public DateTime(){

    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }

    public int getYears() {
        return years;
    }

    public void setYears(int years) {
        this.years = years;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }
}
