package models;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "w1698446_Book")
public class Book extends LibraryItem {

    private int w1698446_totPages;

    private String w1698446_authorOfBook;

    private String w1698446_publisherOfBook;

    public Book(String w1698446_ItemISBN, String w1698446_itemTitle, String w1698446_itemSector, String w1698446_dateOfPublication, int w1698446_totPages, String w1698446_authorOfBook, String w1698446_publisherOfBook) {
        super(w1698446_ItemISBN, w1698446_itemTitle, w1698446_itemSector, w1698446_dateOfPublication);
        this.w1698446_totPages = w1698446_totPages;
        this.w1698446_authorOfBook = w1698446_authorOfBook;
        this.w1698446_publisherOfBook = w1698446_publisherOfBook;
    }

    public String getW1698446_authorOfBook() {
        return w1698446_authorOfBook;
    }

    public void setW1698446_authorOfBook(String w1698446_authorOfBook) {
        this.w1698446_authorOfBook = w1698446_authorOfBook;
    }

    public String getW1698446_publisherOfBook() {
        return w1698446_publisherOfBook;
    }

    public void setW1698446_publisherOfBook(String w1698446_publisherOfBook) {
        this.w1698446_publisherOfBook = w1698446_publisherOfBook;
    }

    public int getW1698446_totPages() {
        return w1698446_totPages;
    }

    public void setW1698446_totPages(int w1698446_totPages) {
        this.w1698446_totPages = w1698446_totPages;
    }
}
