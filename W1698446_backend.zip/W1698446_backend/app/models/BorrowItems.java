package models;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "w1698446_BorrowItems")
public class BorrowItems extends Reader {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long w1698446_id;

    @NotNull
    private String w1698446_borrowedDate;

    @NotNull
    private String w1698446_returnedDate;

    @NotNull
    private String w1698446_itemISBN;

    @NotNull
    private boolean w1698446_itemType;

    @NotNull
    private boolean w1698446_isItemReturn;

    private String w1698446_countValue;

    public BorrowItems(String w1698446_readerId, String w1698446_readerName, String w1698446_readerPhone, String w1698446_readerEmail, String w1698446_borrowedDate, String w1698446_returnedDate, String w1698446_itemISBN, boolean w1698446_itemType, boolean w1698446_isItemReturn, String w1698446_countValue) {
        super(w1698446_readerId, w1698446_readerName, w1698446_readerPhone, w1698446_readerEmail);
        this.w1698446_borrowedDate = w1698446_borrowedDate;
        this.w1698446_returnedDate = w1698446_returnedDate;
        this.w1698446_itemISBN = w1698446_itemISBN;
        this.w1698446_itemType = w1698446_itemType;
        this.w1698446_isItemReturn = w1698446_isItemReturn;
        this.w1698446_countValue = w1698446_countValue;
    }

    public long getW1698446_id() {
        return w1698446_id;
    }

    public void setW1698446_id(long w1698446_id) {
        this.w1698446_id = w1698446_id;
    }

    public String getW1698446_borrowedDate() {
        return w1698446_borrowedDate;
    }

    public void setW1698446_borrowedDate(String w1698446_borrowedDate) {
        this.w1698446_borrowedDate = w1698446_borrowedDate;
    }

    public String getW1698446_returnedDate() {
        return w1698446_returnedDate;
    }

    public void setW1698446_returnedDate(String w1698446_returnedDate) {
        this.w1698446_returnedDate = w1698446_returnedDate;
    }

    public String getW1698446_itemISBN() {
        return w1698446_itemISBN;
    }

    public void setW1698446_itemISBN(String w1698446_itemISBN) {
        this.w1698446_itemISBN = w1698446_itemISBN;
    }

    public boolean isW1698446_itemType() {
        return w1698446_itemType;
    }

    public void setW1698446_itemType(boolean w1698446_itemType) {
        this.w1698446_itemType = w1698446_itemType;
    }

    public boolean isW1698446_isItemReturn() {
        return w1698446_isItemReturn;
    }

    public void setW1698446_isItemReturn(boolean w1698446_isItemReturn) {
        this.w1698446_isItemReturn = w1698446_isItemReturn;
    }

    public String getW1698446_countValue() {
        return w1698446_countValue;
    }

    public void setW1698446_countValue(String w1698446_countValue) {
        this.w1698446_countValue = w1698446_countValue;
    }
}
