# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table w1698446_book (
  w1698446_item_isbn            varchar(255) not null,
  w1698446_item_title           varchar(255),
  w1698446_item_sector          varchar(255),
  w1698446_date_of_publication  varchar(255),
  w1698446_tot_pages            integer,
  w1698446_author_of_book       varchar(255),
  w1698446_publisher_of_book    varchar(255),
  constraint pk_w1698446_book primary key (w1698446_item_isbn)
);

create table w1698446_borrowhistory (
  w1698446_id                   bigint auto_increment not null,
  w1698446_reader_id            varchar(255),
  w1698446_reader_name          varchar(255),
  w1698446_reader_phone         varchar(255),
  w1698446_reader_email         varchar(255),
  w1698446_borrowed_date        varchar(255) not null,
  w1698446_returned_date        varchar(255) not null,
  w1698446_item_isbn            varchar(255) not null,
  w1698446_item_type            tinyint(1) default 0 not null,
  w1698446_is_item_return       tinyint(1) default 0 not null,
  w1698446_count_value          varchar(255),
  constraint pk_w1698446_borrowhistory primary key (w1698446_id)
);

create table w1698446_borrowitems (
  w1698446_id                   bigint auto_increment not null,
  w1698446_reader_id            varchar(255),
  w1698446_reader_name          varchar(255),
  w1698446_reader_phone         varchar(255),
  w1698446_reader_email         varchar(255),
  w1698446_borrowed_date        varchar(255) not null,
  w1698446_returned_date        varchar(255) not null,
  w1698446_item_isbn            varchar(255) not null,
  w1698446_item_type            tinyint(1) default 0 not null,
  w1698446_is_item_return       tinyint(1) default 0 not null,
  w1698446_count_value          varchar(255),
  constraint pk_w1698446_borrowitems primary key (w1698446_id)
);

create table w1698446_dvd (
  w1698446_item_isbn            varchar(255) not null,
  w1698446_item_title           varchar(255),
  w1698446_item_sector          varchar(255),
  w1698446_date_of_publication  varchar(255),
  w1698446_available_languages  varchar(255),
  w1698446_available_subtitles  varchar(255),
  w1698446_producer             varchar(255),
  w1698446_actors               varchar(255),
  constraint pk_w1698446_dvd primary key (w1698446_item_isbn)
);


# --- !Downs

drop table if exists w1698446_book;

drop table if exists w1698446_borrowhistory;

drop table if exists w1698446_borrowitems;

drop table if exists w1698446_dvd;

